import json
import os

i = 0
output = ''

for root, dirs, files in os.walk('C:\\Users\\ErikF\\Downloads\\AutoRclone\\accounts'):
    for file in files:
        if file.endswith('.json'):
            i = i + 1
            f = open(file)
            config = json.loads(f.read())
            sa_email = config['client_email']
            output = output + sa_email + ', '
            if i % 10 == 0:
                print(output)
                print('\n')
                output = ''

            # print(sa_email)
